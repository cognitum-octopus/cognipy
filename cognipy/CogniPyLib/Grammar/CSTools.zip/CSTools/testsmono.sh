mono lg.exe ex323.lexer
mono pg.exe ex323.parser
mcs /debug+ /r:Tools.dll ex.cs ex323.lexer.cs ex323.parser.cs
mono ex.exe ex323.txt
mono lg.exe 21.lexer
mcs /debug+ /r:Tools.dll testlexer.cs 21.lexer.cs
mono testlexer.exe 21.txt
mono lg.exe 22.lexer
mcs /debug+ /r:Tools.dll testlexer.cs 22.lexer.cs
mono testlexer.exe 22.txt
mono lg.exe 23.lexer
mcs /debug+ /r:Tools.dll testlexer.cs 23.lexer.cs
mono testlexer.exe 23.txt
mono lg.exe 24.lexer
mcs /debug+ /r:Tools.dll testlexer.cs 24.lexer.cs
mono testlexer.exe 24.txt
mono lg.exe 26.lexer
mcs /debug+ /r:Tools.dll testlexer.cs 26.lexer.cs
mono testlexer.exe 26.txt
mono lg.exe 27.lexer
mcs /debug+ /r:Tools.dll testlexer.cs 27.lexer.cs
mono testlexer.exe 27.txt
mono lg.exe 31.lexer
mono pg.exe 31.parser
mcs /debug+ /r:Tools.dll ex.cs 31.lexer.cs 31.parser.cs
mono ex.exe 31.txt
mono pg.exe 32.parser
mcs /debug+ /r:Tools.dll 32.cs 23.lexer.cs 32.parser.cs
mono 32.exe 32.txt
mono pg.exe 33.parser
mcs /debug+ /r:Tools.dll 33.cs 23.lexer.cs 33.parser.cs
mono 33.exe 32.txt
mono lg.exe 37.lexer
mono pg.exe 37.parser
mcs /debug+ /r:Tools.dll 37.cs 37.lexer.cs 37.parser.cs
mono 37.exe 37.txt
mono pg.exe 34.parser
mcs /debug+ /r:Tools.dll ex.cs 23.lexer.cs 34.parser.cs
mono ex.exe 34.txt
mono ex.exe 34e.txt
mono pg.exe 35.parser
mcs /debug+ /r:Tools.dll 32.cs 23.lexer.cs 35.parser.cs
mono 32.exe 32.txt
mono lg.exe 42.lexer
mono pg.exe 42.parser
mcs /debug+ /r:Tools.dll 42.cs 42.lexer.cs 42.parser.cs
mono 42.exe 42.txt
mono lg.exe 44.lexer
mono pg.exe 44.parser
mcs /debug+ /r:Tools.dll 44.cs 44.lexer.cs 44.parser.cs
mono 44.exe 44.txt
mono pg.exe 65.parser
mcs /debug+ /r:Tools.dll ex.cs 23.lexer.cs 65.parser.cs
mono ex.exe 65.txt
