using System ;
using System.IO ;
using RayCustom ;
using Tools ;

public class ex
{
public static void Main(string[] argv) 
{
/*
	Lexer lexer = new Rlexer();
	lexer.Start(new StreamReader(argv[0]));
	foreach(TOKEN tok in lexer) {
		Console.WriteLine("{0} {1}", tok.GetType().Name, tok.yytext);
	}
*/

	Parser p = new syntax();
	p.m_debug = true;
	StreamReader s = new StreamReader(argv[0]);
	if (p.Parse(s)!=null)
		Console.WriteLine("Success");

}
}
/*
using System;
using System.Drawing;
using Microsoft.DirectX;
using Container = System.ComponentModel.Container;
/// <summary>
/// The main windows form for the application.
/// </summary>
public class MainClass{

    private GraphicsClass graphics = null;

    /// <summary>
    // Main entry point of the application.
    /// </summary>
    public static void Main()
    {
        MainClass m = new MainClass();
    }

    public MainClass()
    {
        try
        {
            graphics = new GraphicsClass();
        }
        catch(DirectXException)
        {
            return;
        }
        if( graphics.CreateGraphicsSample() )
            graphics.Run();
    }
}
*/