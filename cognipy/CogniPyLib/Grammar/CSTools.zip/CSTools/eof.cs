using System.IO;

public class ex
{
	public static void Main(string[] argv) {
		Parser p = new syntax(new tokens());
		p.m_showParser = true;
		p.m_debug= true;
		StreamReader s = new StreamReader(argv[0]);
		SYMBOL sym = p.Parse(s);
		if (sym!=null) 
		{
			System.Console.WriteLine("Success");
			file f = (file)sym;
			System.Console.WriteLine(""+f.nlines+" lines, "+f.nchars+" chars");
			if (f.trunc)
				System.Console.WriteLine("Last line truncated");
		}
	}
}
