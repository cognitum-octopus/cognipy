using System;
using System.IO;
using Tools;

public class ex
{
	public static void Main(string[] argv) {
		Parser p = new syntax();
		StreamReader s = new StreamReader(argv[0]);
		exp ast = (exp)p.Parse(s);
		if (ast!=null)
			Console.WriteLine((int)(ast.yylval));
	}
}
