// testlexer.cs
using System;
using System.IO;
using System.Text;

public class testtigerlexer {
public static void Main(string[] argv){
	Lexer lexer = new tokens();
//	lexer.m_debug = true;
	string fname = "test1.tig";
	if (argv.Length>0)
		fname = argv[0];
	lexer.Start(new StreamReader(fname,new ASCIIEncoding(),true,1024));
	foreach(TOKEN tok in lexer) {
	    Console.Write(tok.Pos);
		switch (tok.Name()) {
			case "STRING": Console.WriteLine(" STRING <{0}>",((STRING)tok).val);
						break;
			default:
					Console.WriteLine(" {0} {1}", tok.Name(), tok.yytext); break;
		}
	}
}}
