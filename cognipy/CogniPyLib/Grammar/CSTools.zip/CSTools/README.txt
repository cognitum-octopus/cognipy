These tools comprise a lexer generator and a LALR(1) parser generator,
written entirely in C# and generating C#.

This is Version 4.7m of these tools. (See below for change information)

On Windows it requires the .NET Framework to run, currently v.1.1.
On Linux it requires mono.

The tools are
	lg.exe
	pg.exe
	Tools.dll

The documentation is in
	README.txt (this file)
	Booklet.doc

The source files for the tools are
	AssemblyInfo.cs
	genbase0.cs
	genbase.cs
	lg.cs
	olist.cs
	parser.cs
	pg.cs
	pg.lexer
	cs0.lexer
	cs0.parser
	toolcs.bat

The remaining files in this distribution are samples etc.

Rebuilding the tools from the sources:

toolcs.bat rebuilds Tools.dll, lg.exe and pg.exe 
from the sources in a two-stage bootstrap procedure, 
described in section 7.7 of the accompanying booklet: 

Step 1: generates a Tools.dll that supports lexer 
		generation, using genbase0.cs;
		creates a preliminary version of the 
		lexer-generator lg.exe;
		uses this on pg.lexer and builds a 
		preliminary version of pg.exe
Step 2: uses the resulting lg and pg to create 
		class-definition lexer/parser using cs0 
		scripts and builds a full version of 
		Tools.dll

During this process, the C# compiler issues a number of 
warnings about unreachable code. This is a feature of 
the tools: there is one such warning for each OldAction 
clause in lexer and parser scripts. The cs0.parser script 
also has three harmless shift/reduce conflicts.

On Windows, if you want a version of the library to place in the 
global assembly cache (gac) run the script gacvers.bat.
This creates a signed version of Tools.dll, links 
lg and pg to use this, and places the signed library 
Tools.dll in the global assembly cache. This makes 
executables independent of the dll.

You should use the same version (e.g. 4.5) of lg, pg, and Tools
when preparing an assembly. Changes to letter suffixes 
(e.g. 4.5 to 4.5a) should not affect binary compatibility.
Source compatibility is preserved across minor version changes
(e.g. 4.4 to 4.5), but not across changes in major version 
numbers (e.g. 3.10 to 4.0).

CHANGE INFORMATION:
  3.9 introduced the ASCIICAPS encoding (hence a new version)
  3.9a fixed a bug with complemented ranges [^  ] in lexer
  3.9b fixed a bug in the LineManager
  3.9c introduced the Pos property of TOKEN and SYMBOL
	fixed a bug in Parser error recovery, and added
	something about base classes in Appendix A and B in the doc
  3.10 introduced the ErrorHandler class (hence a new version)
  3.10a improved the ErrorHandler class and fixed gacvers.bat
  3.10b improved handling of fatal errors
  3.10c reintroduced -C flag for encoding of lexer and parser files
  **************************************************************
  4.0 changed file naming rules and command line arguments
	  %parser directive must name tokens file
      %lexer and %parser directive text is not ignored
      "new syntax()" instead of "new syntax(new tokens())"
  **************************************************************
  4.0a Fix to illegal character error reporting
  4.0b Fix to class declaration
  4.0c Default int cast added to SYMBOL to improve action behaviour
  4.0d Fix to %a() behaviour in parser actions
  4.0e Removal of partial Javascript semcolon insertion code (was in #if)
  4.0f Allow - in script file names, improve script error reporting
  4.0g Support -K (keep going) flag for ParserGenerator, fix regex doc
  4.0h Support %null in both lexer and parser scripts
  4.0i Fixed error in class definition constructor handling
  4.0j pg -D now implies -K; fix to ex3-23.parser
  4.0k Documentation correction: algorithms are SLR(1) not LALR(1)
  4.0m Fix to avoid infinite loop on EOF error recovery
  4.1 Introduced full LALR(1) algorithms from DeRemer and Pennello
  4.1a Fix to LALR(1). Implements REJECT
  4.2 Separate ParsingInfo for Symbols and Literals
  4.3 Build concrete syntax tree by default
  4.3a Support case-insensitive strings in lexer using U" and U'
  4.3b Support Line and Position in TOKEN and SYMBOL in addition to Pos
  4.3c Some bug fixes and inclusion of Don Syme's F# interop sample
  4.3d Correction to lexer for use with several input files
  4.3e Fix to above on line number counting for lexer
  4.4 Better compatibility with .NET Compact Framework
  4.4a Fix to ASCIICAPS encoding support
  4.4b Doc fix on %node in lexer script, bugfix for quoted aliases
  4.4c Changes to the error symbol for diagnostics on error recovery
  4.4d Changes to error handling
  4.4e SourceLineInfo for CSToolsExceptions
  4.5 Serialisation version check. Fixes to class defs, use of yytext
  4.5a Workaround in serialisation for mono and .sh files for mono use
  4.5b Some fixes to Error/Exception handling
  4.5c Checking on usage of %symbols and %nodes (error 46)
  4.5d Fix to error 46 and addition of sec 4.3 and 4.4 in Booklet
  4.5e Allow C# attributes in parser scripts, add SYMBOL to CSException
  4.5f Fix to FixDollars allowing $10, $11 etc
  4.5g Fix for pg for %node{oldAction} handling
  4.5h Correction for 4.5g and nonassoc handling
  (4.6 was a version for use with the .NET Framework v2.0 beta)
  4.7  Use symbol numbers instead of symbol strings during parsing
  4.7a New support for reserved words collections
  4.7b Fix to error recovery
  4.7c Fix to improve error reporting for script errors
  4.7d IsNullable() corrections and improvements by Wayne Kelly
  4.7e Quoted $ not a placeholder
  4.7f \0 allowed in quoted strings in lexer scripts
  4.7g \v supported
  4.7h [] bug fixed ([] is useless but lg should not crash)
  4.7i support for more Encodings, and trailing {
  4.7j fix to comment handling in input scripts
  4.7k fix to regular expression processing
  4.7m fix to Precedence and Null processing

(c) 2009 Malcolm Crowe, University of the West of Scotland, 
http://cis.paisley.ac.uk/crow-ci0

