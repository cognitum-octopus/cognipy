using System.IO;

public class TigerParser
{
	public static void Main(string[] argv) {
		Parser p = new syntax();
		StreamReader s = new StreamReader(argv[0]);
		p.m_debug = true;
		exp ast = (exp)p.Parse(s);
		if (ast!=null)
			Console.WriteLine("Success");
	}
}
