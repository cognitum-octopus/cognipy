using System.IO;
using System;
using Tools;

public abstract class Table { 
	public abstract int lookup(string id);
}

public class EmptyTable : Table {
	public override int lookup(string id) { 
		throw new Exception("empty Table"); 
	}
}

public class Update : Table {
	Table bas;
	string id;
	int val;
	public Update(Table b, string i, int v) {
		bas = b; id = i; val = v;
	}
	public override int lookup(string i) {
		if (i.Equals(id))
			return val;
		return bas.lookup(i);
	}
}

public class ex {
	public static void Main(string[] args) {
		Parser p = new syntax();
//		p.m_debug = true;
		p.Parse(new StreamReader(args[0]));
	}
}
