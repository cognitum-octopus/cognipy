// testlexer.cs
using System;
using System.IO;
using Tools;

public class testlexer {
public static void Main(string[] argv){
	Lexer lexer = new tokens();
//	lexer.m_debug = true;
	string fname = "test.txt";
	if (argv.Length>0)
		fname = argv[0];
	lexer.Start(new StreamReader(fname));
	foreach(TOKEN tok in lexer) 
		Console.WriteLine("{0} {1} {2}", tok.Pos, tok.yyname, tok.yytext);
}}
