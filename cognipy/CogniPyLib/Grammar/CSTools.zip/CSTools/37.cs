using System.IO;
using System;
using Tools;

public class ex
{
	public static void Main(string[] argv) {
		Parser p = new syntax();
		StreamReader s = new StreamReader(argv[0]);
		E ast = (E)p.Parse(s);
		if (ast!=null)   // get null on syntax error
			Console.WriteLine(ast.str);
	}
}
