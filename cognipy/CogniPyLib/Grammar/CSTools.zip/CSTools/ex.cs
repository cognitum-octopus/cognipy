using System.IO;
using Tools;

public class ex
{
	public static void Main(string[] argv) {
		Parser p = new syntax();
//		p.m_debug=true;
		StreamReader s = new StreamReader(argv[0]);
		SYMBOL ast = p.Parse(s);
		if (ast!=null)
			ast.ConcreteSyntaxTree();
	}
}
