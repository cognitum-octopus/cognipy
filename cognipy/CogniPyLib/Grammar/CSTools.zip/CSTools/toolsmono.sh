mcs -debug+ -out:Tools.dll -target:library -define:GENTIME dfa.cs lexer.cs parser.cs olist.cs serialise.cs genbase0.cs
mcs -debug+ -r:Tools.dll lg.cs
mono lg.exe pg.lexer
mcs -debug+ -r:Tools.dll pg.cs pg.lexer.cs
mono lg.exe cs0.lexer
mono pg.exe cs0.parser
mcs -debug+ -out:Tools.dll -target:library -define:GENTIME dfa.cs lexer.cs parser.cs olist.cs serialise.cs genbase.cs cs0.lexer.cs cs0.parser.cs
mcs -debug+ -r:Tools.dll lg.cs
mcs -debug+ -r:Tools.dll pg.cs pg.lexer.cs 
mcs -debug+ -out:runtime-Tools.dll -target:library dfa.cs lexer.cs parser.cs olist.cs serialise.cs

