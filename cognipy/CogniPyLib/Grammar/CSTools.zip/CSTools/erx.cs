using System.IO;
using Tools;

public class MyErrorHandler : ErrorHandler
{
	public MyErrorHandler() {}
	public override void Report(CSToolsException e)
	{
		base.Report(e);
		System.Console.WriteLine(e.slInfo.sourceLine);
		string s = "";
		if (e.slInfo.charPosition>0)
			s = new string(' ',e.slInfo.charPosition);
		System.Console.WriteLine(s+"^");
	}
}

public class erx
{
	public static void Main(string[] argv) {
		Parser p = new syntax(new yysyntax(),new MyErrorHandler());
		StreamReader s = new StreamReader(argv[0]);
		SYMBOL ast = p.Parse(s);
		if (ast!=null) 
		{
			System.Console.WriteLine("Concrete Syntax Tree");
			ast.ConcreteSyntaxTree();
		}
	}
}
