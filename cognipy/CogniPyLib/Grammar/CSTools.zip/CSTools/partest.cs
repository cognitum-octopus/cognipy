using System;
using System.IO;
using Tools;
using Snack;

public class App {
  public static void Main()
  {
    Parser p = new syntax();
    p.m_debug = true;
    StreamReader s = new StreamReader(Console.OpenStandardInput());
    SYMBOL sym = p.Parse(s);
    if (sym != null && !(sym is error)) {
      sym.ConcreteSyntaxTree();

      foreach (decl i in (sym as decls).ToArray()) {
        if (i is GlobalDecl) {
          Console.WriteLine("Globals{");
          foreach (varinit v in (i as GlobalDecl).varinits) {
            Console.Write("  {0}", v.name);
            if (v.value != null)
              Console.Write(" (initialized w/ {0})", v.value.GetType());
            Console.WriteLine();
          }
          Console.WriteLine("}");
        } else if (i is FunctionDecl) {
          FunctionDecl fd = i as FunctionDecl;
          Console.Write("Function '{0}' (", fd.name);
          if (fd.prototype == null)
            Console.Write("no prototype");
          else
            foreach (string str in fd.prototype)
              Console.Write("{0} ", str);
          Console.WriteLine(") {");
          stmt l = fd.code.first;
          while (l != null) {
            Console.WriteLine("  {0}", l.GetType());
            l = l.next;
          }
          Console.WriteLine("}");
        } else
          Console.WriteLine(i.GetType());
      }
    }
  }
}

